# Chujeet Vigneash Portfolio — Setup & Deploy

## 1. Install
```bash
npm install
```

## 2. Local preview
```bash
npm run dev
```

## 3. Production build
```bash
npm run build
npm run preview
```

## 4. Add your resume
Put your PDF at:
`public/Chujeet_Vigneash_Resume.pdf`

## 5. Update links
Edit `src/main.jsx`:
- `profile.github`
- project links if you have repositories

## 6. GitHub Pages
Create a repository and push this project to `main`.
Then open:
Settings → Pages → Build and deployment → Source → GitHub Actions.

The included workflow will build and deploy automatically after pushes to `main`.
