import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  ArrowDown, ArrowUpRight, Award, BriefcaseBusiness, CheckCircle2,
  ChevronRight, Cloud, Code2, Download, ExternalLink, Github,
  GraduationCap, Linkedin, Mail, Menu, Server, ShieldCheck,
  Sparkles, Terminal, Trophy, X
} from "lucide-react";
import "./styles.css";

const profile = {
  name: "Chujeet Vigneash A",
  role: "DevOps Engineer",
  location: "India",
  email: "chujeetvigneash@gmail.com",
  phone: "+91 73959 31733",
  linkedin: "https://www.linkedin.com/in/chujeet-vigneash",
  github: "https://github.com/chujeetraina03",
  resume: "/Chujeet_Vigneash_Resume.pdf"
};

const skills = [
  ["Cloud", "AWS, Azure, Azure DevOps", Cloud],
  ["CI/CD", "Jenkins, GitHub Actions, Azure Pipelines", Terminal],
  ["Infrastructure", "Terraform, Ansible", Server],
  ["Containers", "Docker, Kubernetes, ECS", Code2],
  ["Quality & Monitoring", "SonarQube, Dynatrace, Nagios", ShieldCheck],
  ["Engineering", "Git, GitFlow, Python, Groovy, YAML", Code2]
];

const experience = [
  {
    period: "10/2023 — Present",
    role: "DevOps Engineer",
    company: "Cognizant Technology Solutions",
    bullets: [
      "Implemented Azure YAML pipelines to build Docker images and publish them to Amazon ECR and ECS.",
      "Built and operated multiple API pipelines daily, owning build and release activities across deployments.",
      "Used GitHub Copilot to accelerate automation scripting and YAML development.",
      "Used SonarQube to identify and eliminate 100+ code vulnerabilities, raising project quality above 80%.",
      "Spearheaded Infrastructure as Code adoption using Terraform.",
      "Implemented GitFlow branching practices, reducing merge conflicts by 30%.",
      "Used Ansible automation to reduce deployment errors and manual intervention."
    ]
  },
  {
    period: "05/2022 — 09/2023",
    role: "Junior DevOps Engineer",
    company: "Cognizant Technology Solutions",
    bullets: [
      "Engineered Jenkins CI/CD pipelines covering build, test and deployment, reducing manual deployment effort by 50%.",
      "Managed multi-squad releases, dependencies, deployment bridges and release-risk communication.",
      "Embedded SonarQube security scanning into Jenkins workflows to strengthen DevSecOps practices.",
      "Monitored application and infrastructure health using Dynatrace and investigated critical alerts.",
      "Contributed to Jenkins-to-GitHub Actions migration using Groovy and Python automation.",
      "Managed release lifecycles with Jira and maintained deployment runbooks in Confluence.",
      "Handled production change governance through ServiceNow."
    ]
  }
];

const projects = [
  {
    title: "CI/CD Modernization",
    tag: "DevOps",
    description: "Modernized legacy CI/CD workflows by combining Jenkins, GitHub Actions, Azure Pipelines, automated quality gates and release practices.",
    stack: ["Jenkins", "GitHub Actions", "Azure DevOps", "SonarQube"]
  },
  {
    title: "AWS Container Delivery",
    tag: "Cloud",
    description: "Automated Docker image creation and delivery from Azure pipelines into AWS ECR and ECS for API deployments.",
    stack: ["AWS ECR", "ECS", "Docker", "YAML"]
  },
  {
    title: "Infrastructure as Code",
    tag: "Automation",
    description: "Introduced repeatable infrastructure and deployment automation using Terraform and Ansible to reduce manual configuration and deployment risk.",
    stack: ["Terraform", "Ansible", "AWS", "Azure"]
  }
];

const achievements = [
  ["Best Performer", "Client appreciation for creating and achieving a new milestone with a 100% success rate.", Award],
  ["AI & DevOps Certifications", "Certifications in GitHub Copilot and Generative AI for DevOps.", Sparkles],
  ["Chess Achievement", "FIDE-rated chess player with an All India Inter-University Gold Medal and international tournament participation.", Trophy],
  ["Knowledge Sharing", "Recognized by project management for supporting knowledge-transfer sessions for new resources.", GraduationCap]
];

function SectionTitle({ eyebrow, title, text }) {
  return (
    <div className="section-title">
      <span>{eyebrow}</span>
      <h2>{title}</h2>
      {text && <p>{text}</p>}
    </div>
  );
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [active, setActive] = useState("home");

  useEffect(() => {
    const onScroll = () => {
      const sections = ["home", "about", "experience", "skills", "projects", "achievements", "contact"];
      const y = window.scrollY + 180;
      for (const id of sections) {
        const el = document.getElementById(id);
        if (el && y >= el.offsetTop && y < el.offsetTop + el.offsetHeight) {
          setActive(id);
          break;
        }
      }
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="site">
      <div className="glow glow-one" />
      <div className="glow glow-two" />

      <header className="nav">
        <a className="brand" href="#home" onClick={closeMenu}>
          <span className="brand-mark">CV</span>
          <span>Chujeet.</span>
        </a>

        <button className="menu-button" aria-label="Toggle menu" onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>

        <nav className={menuOpen ? "nav-links open" : "nav-links"}>
          {["home", "about", "experience", "skills", "projects", "achievements", "contact"].map((item) => (
            <a key={item} className={active === item ? "active" : ""} href={`#${item}`} onClick={closeMenu}>
              {item}
            </a>
          ))}
        </nav>
        <a className="nav-cta" href={profile.linkedin} target="_blank" rel="noreferrer">Let's connect <ArrowUpRight size={16}/></a>
      </header>

      <main>
        <section id="home" className="hero section">
          <div className="hero-copy">
            <div className="eyebrow"><span className="pulse-dot" /> DEVOPS • CLOUD • AUTOMATION</div>
            <h1>Building reliable<br /><em>delivery systems.</em></h1>
            <p className="hero-text">
              I'm <strong>Chujeet Vigneash</strong>, a DevOps Engineer focused on cloud-native delivery,
              infrastructure automation and CI/CD modernization.
            </p>
            <div className="hero-actions">
              <a className="button primary" href="#projects">Explore my work <ArrowDown size={17}/></a>
              <a className="button secondary" href={profile.resume} download>Download resume <Download size={17}/></a>
            </div>
            <div className="quick-stats">
              <div><strong>4+</strong><span>Years in DevOps</span></div>
              <div><strong>50%</strong><span>Less manual deployment effort</span></div>
              <div><strong>100+</strong><span>Vulnerabilities addressed</span></div>
            </div>
          </div>

          <div className="hero-visual">
            <div className="terminal-card">
              <div className="terminal-top">
                <span className="window-dots"><i/><i/><i/></span>
                <span>~/chujeet/devops</span>
                <span>•••</span>
              </div>
              <div className="terminal-body">
                <p><span className="muted">$</span> whoami</p>
                <h3>devops_engineer</h3>
                <p><span className="muted">$</span> cat stack.yml</p>
                <div className="code-lines">
                  <div><b>cloud:</b> AWS + Azure</div>
                  <div><b>iac:</b> Terraform + Ansible</div>
                  <div><b>containers:</b> Docker + Kubernetes</div>
                  <div><b>cicd:</b> Jenkins + GitHub Actions</div>
                  <div><b>quality:</b> SonarQube</div>
                </div>
                <p className="cursor-line"><span className="muted">$</span> ship --reliably <span className="cursor">▋</span></p>
              </div>
            </div>
            <div className="orbit orbit-a"><Cloud size={22}/></div>
            <div className="orbit orbit-b"><Terminal size={20}/></div>
            <div className="orbit orbit-c"><Server size={19}/></div>
          </div>
        </section>

        <section id="about" className="section narrow">
          <SectionTitle eyebrow="01 / ABOUT" title="Engineering with automation in mind." text="A practical DevOps profile built around repeatability, quality and delivery speed." />
          <div className="about-grid">
            <div className="about-card featured">
              <div className="icon-box"><Cloud size={24}/></div>
              <h3>Cloud & Delivery</h3>
              <p>Hands-on experience designing and operating CI/CD workflows across Azure and AWS, with Docker-based delivery into ECS/ECR.</p>
            </div>
            <div className="about-card">
              <div className="icon-box"><Server size={24}/></div>
              <h3>Infrastructure</h3>
              <p>Infrastructure as Code with Terraform and deployment automation with Ansible to make environments consistent and repeatable.</p>
            </div>
            <div className="about-card">
              <div className="icon-box"><ShieldCheck size={24}/></div>
              <h3>Quality & Reliability</h3>
              <p>DevSecOps practices with SonarQube plus operational monitoring through Dynatrace and Nagios.</p>
            </div>
          </div>
        </section>

        <section id="experience" className="section dark-section">
          <div className="narrow">
            <SectionTitle eyebrow="02 / EXPERIENCE" title="From pipeline engineering to cloud automation." />
            <div className="timeline">
              {experience.map((job) => (
                <article className="timeline-item" key={job.period}>
                  <div className="timeline-dot" />
                  <div className="timeline-date">{job.period}</div>
                  <div className="timeline-content">
                    <h3>{job.role}</h3>
                    <h4>{job.company}</h4>
                    <ul>{job.bullets.map((b, i) => <li key={i}><CheckCircle2 size={15}/>{b}</li>)}</ul>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="skills" className="section narrow">
          <SectionTitle eyebrow="03 / SKILLS" title="Tools I use to ship." text="A focused toolkit across cloud, automation, containers, CI/CD and engineering operations." />
          <div className="skills-grid">
            {skills.map(([title, text, Icon]) => (
              <div className="skill-card" key={title}>
                <div className="skill-icon"><Icon size={21}/></div>
                <div><h3>{title}</h3><p>{text}</p></div>
              </div>
            ))}
          </div>
        </section>

        <section id="projects" className="section dark-section">
          <div className="narrow">
            <SectionTitle eyebrow="04 / PROJECTS" title="Selected work & initiatives." />
            <div className="project-grid">
              {projects.map((project, index) => (
                <article className="project-card" key={project.title}>
                  <div className="project-number">0{index + 1}</div>
                  <span className="tag">{project.tag}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <div className="chips">{project.stack.map(s => <span key={s}>{s}</span>)}</div>
                  <a href={profile.github} target="_blank" rel="noreferrer">View on GitHub <ExternalLink size={16}/></a>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="achievements" className="section narrow">
          <SectionTitle eyebrow="05 / ACHIEVEMENTS" title="Beyond the day job." text="Professional recognition, continuous learning and competitive thinking." />
          <div className="achievement-grid">
            {achievements.map(([title, text, Icon]) => (
              <article className="achievement-card" key={title}>
                <div className="achievement-icon"><Icon size={21}/></div>
                <h3>{title}</h3>
                <p>{text}</p>
              </article>
            ))}
          </div>
          <div className="education">
            <GraduationCap size={26}/>
            <div><span>EDUCATION</span><h3>Bachelor of Engineering Technology — Computer Science</h3><p>St. Joseph's College of Engineering, Chennai • 2021 • 82.5%</p></div>
          </div>
        </section>

        <section id="contact" className="section contact-section">
          <div className="contact-card">
            <div>
              <span className="eyebrow">06 / CONTACT</span>
              <h2>Let's build something<br /><em>reliable.</em></h2>
              <p>Open to conversations around DevOps, cloud engineering, automation and opportunities where I can create measurable delivery improvements.</p>
            </div>
            <div className="contact-links">
              <a href={`mailto:${profile.email}`}><Mail size={19}/><span>{profile.email}</span><ArrowUpRight size={16}/></a>
              <a href={profile.linkedin} target="_blank" rel="noreferrer"><Linkedin size={19}/><span>LinkedIn</span><ArrowUpRight size={16}/></a>
              <a href={profile.github} target="_blank" rel="noreferrer"><Github size={19}/><span>GitHub</span><ArrowUpRight size={16}/></a>
            </div>
          </div>
        </section>
      </main>

      <footer>
        <span>© {new Date().getFullYear()} Chujeet Vigneash A</span>
        <span>Designed for DevOps • Built with React + Vite</span>
      </footer>

      <a className="back-top" href="#home" aria-label="Back to top"><ArrowUp size={18}/></a>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
