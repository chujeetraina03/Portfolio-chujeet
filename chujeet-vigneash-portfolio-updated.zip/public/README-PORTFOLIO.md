# Chujeet Vigneash Portfolio

A responsive React + Vite DevOps portfolio.

## Customize before publishing

1. Replace `public/Chujeet_Vigneash_Resume.pdf` with your actual resume using that exact filename.
2. Update `profile.github` in `src/main.jsx` with your GitHub profile URL.
3. Review all project descriptions and add real project repository URLs where available.
4. Run `npm install`.
5. Run `npm run dev` to preview locally.
6. Run `npm run build` before publishing.

## GitHub Pages

This project is configured for a root GitHub Pages site (`https://USERNAME.github.io/`).
If you instead deploy from a repository such as `https://USERNAME.github.io/portfolio/`,
change `base` in `vite.config.js` to `/portfolio/`.

See the GitHub Pages workflow in `.github/workflows/deploy.yml`.
